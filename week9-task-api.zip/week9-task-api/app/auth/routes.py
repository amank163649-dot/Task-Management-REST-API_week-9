from flask import Blueprint, request
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    get_jwt,
    get_jwt_identity,
    jwt_required,
)

from ..extensions import db, limiter
from ..models import TokenBlocklist, User
from ..utils.decorators import json_required
from ..utils.responses import error_response, success_response
from ..utils.validators import validate_registration

bp = Blueprint("auth", __name__)


def _tokens(user):
    identity = str(user.id)
    return {
        "access_token": create_access_token(identity=identity),
        "refresh_token": create_refresh_token(identity=identity),
    }


@bp.post("/register")
@limiter.limit("10 per minute")
@json_required
def register():
    data = request.get_json()
    errors = validate_registration(data)
    if errors:
        return error_response("Validation failed", 400, errors)

    username, email = data["username"].strip(), data["email"].strip().lower()
    if User.query.filter((User.username == username) | (User.email == email)).first():
        return error_response("Username or email already in use", 409)

    user = User(username=username, email=email)
    user.set_password(data["password"])
    db.session.add(user)
    db.session.commit()
    return success_response(
        {"message": "User registered successfully", "user": user.to_dict(), **_tokens(user)},
        201,
    )


@bp.post("/login")
@limiter.limit("10 per minute")
@json_required
def login():
    data = request.get_json()
    user = User.query.filter_by(email=(data.get("email") or "").strip().lower()).first()
    if not user or not user.check_password(data.get("password") or ""):
        return error_response("Invalid email or password", 401)
    return success_response({"user": user.to_dict(), **_tokens(user)})


@bp.post("/refresh")
@jwt_required(refresh=True)
def refresh():
    token = create_access_token(identity=get_jwt_identity())
    return success_response({"access_token": token})


@bp.post("/logout")
@jwt_required()
def logout():
    db.session.add(TokenBlocklist(jti=get_jwt()["jti"]))
    db.session.commit()
    return success_response({"message": "Logged out successfully"})

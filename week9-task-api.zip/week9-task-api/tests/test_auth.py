from conftest import register


def test_register_success(client):
    res = client.post(
        "/api/v1/auth/register",
        json={"username": "john", "email": "john@example.com", "password": "SecurePass123"},
    )
    assert res.status_code == 201
    assert "access_token" in res.get_json()["data"]


def test_register_validation_error(client):
    res = client.post("/api/v1/auth/register", json={"username": "x", "email": "bad", "password": "1"})
    assert res.status_code == 400
    assert set(res.get_json()["errors"]) == {"username", "email", "password"}


def test_register_duplicate(client):
    register(client)
    res = client.post(
        "/api/v1/auth/register",
        json={"username": "john", "email": "john@example.com", "password": "SecurePass123"},
    )
    assert res.status_code == 409


def test_login_success_and_failure(client):
    register(client)
    ok = client.post("/api/v1/auth/login", json={"email": "john@example.com", "password": "SecurePass123"})
    bad = client.post("/api/v1/auth/login", json={"email": "john@example.com", "password": "wrong"})
    assert ok.status_code == 200 and bad.status_code == 401


def test_refresh_token(client):
    refresh = register(client)["refresh_token"]
    res = client.post("/api/v1/auth/refresh", headers={"Authorization": f"Bearer {refresh}"})
    assert res.status_code == 200
    assert "access_token" in res.get_json()["data"]


def test_logout_revokes_token(client, auth):
    assert client.post("/api/v1/auth/logout", headers=auth).status_code == 200
    assert client.get("/api/v1/tasks", headers=auth).status_code == 401


def test_protected_route_requires_token(client):
    res = client.get("/api/v1/tasks")
    assert res.status_code == 401
    assert res.get_json()["status"] == "error"

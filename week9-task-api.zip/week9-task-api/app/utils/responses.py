from flask import jsonify


def success_response(data=None, status_code=200):
    if status_code == 204:
        return "", 204
    return jsonify({"status": "success", "data": data}), status_code


def error_response(message, status_code=400, errors=None):
    body = {"status": "error", "message": message}
    if errors:
        body["errors"] = errors
    return jsonify(body), status_code

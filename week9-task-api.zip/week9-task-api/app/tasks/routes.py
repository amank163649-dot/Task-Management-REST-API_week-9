from datetime import date

from flask import Blueprint, request
from flask_jwt_extended import get_jwt_identity, jwt_required

from ..extensions import db
from ..models import Task
from ..utils.decorators import json_required
from ..utils.responses import error_response, success_response
from ..utils.validators import validate_task

bp = Blueprint("tasks", __name__)

SORTABLE = {"created_at", "updated_at", "due_date", "title", "status", "priority"}
EDITABLE = ("title", "description", "status", "priority", "category", "due_date")


def _owned_task(task_id):
    return Task.query.filter_by(id=task_id, user_id=int(get_jwt_identity())).first()


def _apply(task, data):
    for field in EDITABLE:
        if field in data:
            value = data[field]
            if field == "due_date" and value is not None:
                value = date.fromisoformat(value)
            setattr(task, field, value)


@bp.get("")
@jwt_required()
def list_tasks():
    args = request.args
    query = Task.query.filter_by(user_id=int(get_jwt_identity()))

    for field in ("status", "priority", "category"):
        if args.get(field):
            query = query.filter(getattr(Task, field) == args[field])
    if args.get("q"):
        like = f"%{args['q']}%"
        query = query.filter(Task.title.ilike(like) | Task.description.ilike(like))

    sort_by = args.get("sort_by", "created_at")
    if sort_by not in SORTABLE:
        return error_response(f"sort_by must be one of: {', '.join(sorted(SORTABLE))}", 400)
    column = getattr(Task, sort_by)
    query = query.order_by(column.asc() if args.get("sort_order") == "asc" else column.desc())

    page = max(args.get("page", 1, type=int), 1)
    per_page = min(max(args.get("per_page", 10, type=int), 1), 100)
    result = query.paginate(page=page, per_page=per_page, error_out=False)

    return success_response(
        {
            "tasks": [t.to_dict() for t in result.items],
            "pagination": {
                "page": result.page,
                "per_page": result.per_page,
                "total_pages": result.pages,
                "total_items": result.total,
                "has_next": result.has_next,
                "has_prev": result.has_prev,
            },
        }
    )


@bp.post("")
@jwt_required()
@json_required
def create_task():
    data = request.get_json()
    errors = validate_task(data)
    if errors:
        return error_response("Validation failed", 400, errors)

    task = Task(user_id=int(get_jwt_identity()))
    _apply(task, data)
    db.session.add(task)
    db.session.commit()
    return success_response({"message": "Task created successfully", "task": task.to_dict()}, 201)


@bp.get("/<int:task_id>")
@jwt_required()
def get_task(task_id):
    task = _owned_task(task_id)
    if not task:
        return error_response("Task not found", 404)
    return success_response({"task": task.to_dict()})


@bp.route("/<int:task_id>", methods=["PUT", "PATCH"])
@jwt_required()
@json_required
def update_task(task_id):
    task = _owned_task(task_id)
    if not task:
        return error_response("Task not found", 404)

    data = request.get_json()
    errors = validate_task(data, partial=request.method == "PATCH")
    if errors:
        return error_response("Validation failed", 400, errors)

    _apply(task, data)
    db.session.commit()
    return success_response({"message": "Task updated successfully", "task": task.to_dict()})


@bp.delete("/<int:task_id>")
@jwt_required()
def delete_task(task_id):
    task = _owned_task(task_id)
    if not task:
        return error_response("Task not found", 404)
    db.session.delete(task)
    db.session.commit()
    return success_response(status_code=204)

import logging

from .extensions import db, jwt
from .models import TokenBlocklist
from .utils.responses import error_response

log = logging.getLogger(__name__)


def register_error_handlers(app):
    @app.errorhandler(404)
    def not_found(_):
        return error_response("Resource not found", 404)

    @app.errorhandler(405)
    def method_not_allowed(_):
        return error_response("Method not allowed", 405)

    @app.errorhandler(429)
    def rate_limited(e):
        return error_response(f"Rate limit exceeded: {e.description}", 429)

    @app.errorhandler(500)
    def server_error(e):
        db.session.rollback()
        log.exception("Unhandled error: %s", e)
        return error_response("Internal server error", 500)


@jwt.unauthorized_loader
def missing_token(_):
    return error_response("Missing or invalid token", 401)


@jwt.invalid_token_loader
def invalid_token(_):
    return error_response("Missing or invalid token", 401)


@jwt.expired_token_loader
def expired_token(*_):
    return error_response("Token has expired", 401)


@jwt.revoked_token_loader
def revoked_token(*_):
    return error_response("Token has been revoked", 401)


@jwt.token_in_blocklist_loader
def is_revoked(_header, payload):
    return TokenBlocklist.query.filter_by(jti=payload["jti"]).first() is not None

import logging

from flask import Flask
from flask_cors import CORS

from config import Config

from .extensions import db, jwt, limiter


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s"
    )

    db.init_app(app)
    jwt.init_app(app)
    limiter.init_app(app)
    CORS(app, resources={r"/api/*": {"origins": "*"}})

    from .auth.routes import bp as auth_bp
    from .errors import register_error_handlers
    from .tasks.routes import bp as tasks_bp

    app.register_blueprint(auth_bp, url_prefix="/api/v1/auth")
    app.register_blueprint(tasks_bp, url_prefix="/api/v1/tasks")
    register_error_handlers(app)

    with app.app_context():
        db.create_all()

    return app

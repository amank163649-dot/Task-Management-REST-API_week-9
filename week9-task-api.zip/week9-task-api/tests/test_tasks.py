from conftest import register


def make(client, auth, **kw):
    body = {"title": "Write report", **kw}
    return client.post("/api/v1/tasks", json=body, headers=auth)


def test_create_task_defaults(client, auth):
    res = make(client, auth, due_date="2030-01-15")
    task = res.get_json()["data"]["task"]
    assert res.status_code == 201
    assert task["status"] == "pending" and task["priority"] == "medium"
    assert task["due_date"] == "2030-01-15"


def test_create_task_validation(client, auth):
    res = make(client, auth, title="x", priority="urgent", due_date="15-01-2030")
    assert res.status_code == 400
    assert set(res.get_json()["errors"]) == {"title", "priority", "due_date"}


def test_get_update_delete(client, auth):
    tid = make(client, auth).get_json()["data"]["task"]["id"]
    assert client.get(f"/api/v1/tasks/{tid}", headers=auth).status_code == 200

    patch = client.patch(f"/api/v1/tasks/{tid}", json={"status": "completed"}, headers=auth)
    assert patch.get_json()["data"]["task"]["status"] == "completed"

    put = client.put(f"/api/v1/tasks/{tid}", json={"priority": "high"}, headers=auth)
    assert put.status_code == 400  # PUT requires a full representation (title)

    assert client.delete(f"/api/v1/tasks/{tid}", headers=auth).status_code == 204
    assert client.get(f"/api/v1/tasks/{tid}", headers=auth).status_code == 404


def test_tasks_are_private_per_user(client, auth):
    tid = make(client, auth).get_json()["data"]["task"]["id"]
    other = register(client, "jane", "jane@example.com")["access_token"]
    res = client.get(f"/api/v1/tasks/{tid}", headers={"Authorization": f"Bearer {other}"})
    assert res.status_code == 404


def test_filter_search_sort_paginate(client, auth):
    make(client, auth, title="Alpha task", priority="high", status="completed")
    make(client, auth, title="Bravo task", priority="low", description="groceries")
    make(client, auth, title="Charlie task", priority="high")

    def get(qs):
        return client.get(f"/api/v1/tasks?{qs}", headers=auth).get_json()["data"]

    assert get("priority=high")["pagination"]["total_items"] == 2
    assert get("status=completed")["pagination"]["total_items"] == 1
    assert get("q=grocer")["tasks"][0]["title"] == "Bravo task"
    assert [t["title"] for t in get("sort_by=title&sort_order=asc")["tasks"]][0] == "Alpha task"

    page = get("per_page=2&page=2")
    assert len(page["tasks"]) == 1 and page["pagination"]["has_prev"]


def test_invalid_sort_field(client, auth):
    assert client.get("/api/v1/tasks?sort_by=password", headers=auth).status_code == 400


def test_non_json_body_rejected(client, auth):
    res = client.post("/api/v1/tasks", data="nope", headers=auth)
    assert res.status_code == 400

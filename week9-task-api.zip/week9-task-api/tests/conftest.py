import pytest

from app import create_app
from app.extensions import db
from config import TestConfig


@pytest.fixture()
def client():
    app = create_app(TestConfig)
    with app.app_context():
        db.create_all()
        yield app.test_client()
        db.session.remove()
        db.drop_all()


def register(client, name="john", email="john@example.com"):
    res = client.post(
        "/api/v1/auth/register",
        json={"username": name, "email": email, "password": "SecurePass123"},
    )
    return res.get_json()["data"]


@pytest.fixture()
def auth(client):
    token = register(client)["access_token"]
    return {"Authorization": f"Bearer {token}"}

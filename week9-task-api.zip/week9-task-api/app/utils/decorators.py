from functools import wraps

from flask import request

from .responses import error_response


def json_required(fn):
    """Reject requests whose body is not a JSON object."""

    @wraps(fn)
    def wrapper(*args, **kwargs):
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return error_response("Request body must be a JSON object", 400)
        return fn(*args, **kwargs)

    return wrapper

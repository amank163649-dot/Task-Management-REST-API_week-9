# API Reference

Base URL: `http://localhost:5000/api/v1` · All bodies are JSON · Protected routes need `Authorization: Bearer <access_token>`.

## Response format

```json
{ "status": "success", "data": { } }
{ "status": "error", "message": "Validation failed", "errors": { "title": ["..."] } }
```

## Authentication

| Method | Path | Description | Success |
|---|---|---|---|
| POST | `/auth/register` | Create user, returns tokens | 201 |
| POST | `/auth/login` | Returns access + refresh tokens | 200 |
| POST | `/auth/refresh` | Send the **refresh** token as Bearer; returns new access token | 200 |
| POST | `/auth/logout` | Revokes the current access token | 200 |

Register / login are limited to 10 requests per minute per IP.

```bash
curl -X POST localhost:5000/api/v1/auth/register -H "Content-Type: application/json" \
  -d '{"username":"john","email":"john@example.com","password":"SecurePass123"}'
```

## Tasks

| Method | Path | Description | Success |
|---|---|---|---|
| GET | `/tasks` | List with filters, search, sorting, pagination | 200 |
| POST | `/tasks` | Create | 201 |
| GET | `/tasks/{id}` | Retrieve | 200 |
| PUT | `/tasks/{id}` | Full update (`title` required) | 200 |
| PATCH | `/tasks/{id}` | Partial update | 200 |
| DELETE | `/tasks/{id}` | Delete | 204 |

**Query parameters for `GET /tasks`:** `page` (1), `per_page` (10, max 100), `status`, `priority`, `category`, `q` (search title/description), `sort_by` (`created_at`, `updated_at`, `due_date`, `title`, `status`, `priority`), `sort_order` (`asc`/`desc`).

**Task fields:** `title` (3-120 chars, required), `description`, `status` (`pending`, `in_progress`, `completed`), `priority` (`low`, `medium`, `high`), `category`, `due_date` (`YYYY-MM-DD`).

```bash
curl -X POST localhost:5000/api/v1/tasks -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"Complete API project","priority":"high","due_date":"2030-02-15"}'

curl "localhost:5000/api/v1/tasks?status=pending&sort_by=due_date&sort_order=asc&q=api" \
  -H "Authorization: Bearer $TOKEN"
```

## Status codes

| Code | Meaning |
|---|---|
| 200 / 201 / 204 | OK / Created / Deleted |
| 400 | Validation failed or malformed JSON |
| 401 | Missing, invalid, expired or revoked token |
| 404 | Resource not found (also returned for other users' tasks) |
| 405 | Method not allowed |
| 409 | Username or email already exists |
| 429 | Rate limit exceeded (default 100/hour per IP) |
| 500 | Unexpected server error (logged) |

def test_unknown_route_returns_json_404(client):
    res = client.get("/api/v1/nope")
    assert res.status_code == 404
    assert res.get_json() == {"status": "error", "message": "Resource not found"}


def test_wrong_method_returns_json_405(client):
    res = client.delete("/api/v1/auth/login")
    assert res.status_code == 405
    assert res.get_json()["status"] == "error"

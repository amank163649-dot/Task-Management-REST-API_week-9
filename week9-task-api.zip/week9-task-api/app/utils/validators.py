import re
from datetime import date

STATUSES = ("pending", "in_progress", "completed")
PRIORITIES = ("low", "medium", "high")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_registration(data):
    errors = {}
    username = (data.get("username") or "").strip()
    email = (data.get("email") or "").strip()
    password = data.get("password") or ""
    if not 3 <= len(username) <= 30:
        errors["username"] = ["Username must be 3-30 characters"]
    if not EMAIL_RE.match(email):
        errors["email"] = ["A valid email is required"]
    if len(password) < 8:
        errors["password"] = ["Password must be at least 8 characters"]
    return errors


def validate_task(data, partial=False):
    """Return a dict of field errors (empty when valid)."""
    errors = {}

    if not partial or "title" in data:
        title = data.get("title")
        if not isinstance(title, str) or not 3 <= len(title.strip()) <= 120:
            errors["title"] = ["Title is required (3-120 characters)"]
    if "status" in data and data["status"] not in STATUSES:
        errors["status"] = [f"Status must be one of: {', '.join(STATUSES)}"]
    if "priority" in data and data["priority"] not in PRIORITIES:
        errors["priority"] = [f"Priority must be one of: {', '.join(PRIORITIES)}"]
    if data.get("due_date") is not None:
        try:
            date.fromisoformat(data["due_date"])
        except (TypeError, ValueError):
            errors["due_date"] = ["Due date must be in YYYY-MM-DD format"]
    return errors
